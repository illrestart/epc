#include "ns3/address.h"
#include "ns3/socket.h"
#include "ns3/traced-callback.h"
#include "ns3/callback.h"
#include "ns3/ptr.h"
#include "ns3/object.h"
#include "ns3/application.h"
#include "lte-tag.h"
#include <vector>
#include <iostream>
#include <stdlib.h>
#include "ns3/system-mutex.h"
#include "signal.h"

namespace ns3{

class enbApplication:public Application{
	public:
		static TypeId GetTypeId(void);
	protected:
		void DoDispose(void);
	public:

		enbApplication(Ptr<Node>,Ipv4Address,int,Ipv4Address,int,Ipv4Address,int);
		virtual ~enbApplication(void);
		virtual void StartApplication();
		virtual void StopApplication();
		void RecvFromUeSocket(Ptr<Socket>);
                void RecvFromMmeSocket(Ptr<Socket>);
                void RecvFromUgwSocket(Ptr<Socket>);

		void ProcessThread(void);
		void ProcessPacket(Ptr<Packet>);
		void ProcessSession(lteEpcTag);
		void InitSocket();

		void SendInitialContextSetupComplete(Ptr<Socket>);

		Ptr<Node> m_enbNode;

		Ipv4Address m_ueSocketAddress;
                Ipv4Address m_mmeSocketAddress;
                Ipv4Address m_ugwSocketAddress;
		int m_port;
		Ptr<Socket> m_sendToUeSocket;
		Ptr<Socket> m_sendToMmeSocket;
		Ptr<Socket> m_sendToUgwSocket;
		Ptr<Socket> m_socketUe;
		int m_uePort;
		int m_mmePort;
		int m_ugwPort;

		std::vector< Ptr<Packet> > m_vec;
		SystemMutex m_mutex;
		Signal m_signal;
};

}
