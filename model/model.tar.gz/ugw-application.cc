
#include "ugw-application.h"
#include "ns3/log.h"
#include "ns3/simulator.h"

NS_LOG_COMPONENT_DEFINE("ugwApplication");

namespace ns3{

TypeId ugwApplication::GetTypeId(void){
	static TypeId tid = TypeId("ns3::ugwApplication")
		.SetParent<Object>();
	return tid;
}

void ugwApplication::DoDispose(void){
	NS_LOG_FUNCTION(this);
}

ugwApplication::ugwApplication(Ptr<Node> ugwNode,Ipv4Address enbSocketAddress,int enbport,Ipv4Address controllerSocketAddress,int controllerport)
	:m_ugwNode(ugwNode),
	m_enbSocketAddress(enbSocketAddress),
        m_controllerSocketAddress(controllerSocketAddress),
	m_enbPort(enbport),
	m_controllerPort(controllerport)
{
	m_port = 8086;

	InitSocket();
}
ugwApplication::~ugwApplication(void){
	NS_LOG_FUNCTION(this);
}
void ugwApplication::InitSocket(){
	m_socket = Socket::CreateSocket(m_ugwNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_socket->Bind(InetSocketAddress(Ipv4Address::GetAny(),m_port));

	m_sendToEnbSocket = Socket::CreateSocket(m_ugwNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_sendToEnbSocket->Bind(InetSocketAddress(Ipv4Address::GetAny(),8085));

	m_sendToControllerSocket = Socket::CreateSocket(m_ugwNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_sendToControllerSocket->Bind(InetSocketAddress(Ipv4Address::GetAny(),8084));

}
void ugwApplication::StartApplication(){
	NS_LOG_FUNCTION(this);	
	m_socket->SetRecvCallback(MakeCallback(&ugwApplication::RecvFromEnbSocket,this));
}
void ugwApplication::StopApplication(){
	NS_LOG_FUNCTION(this);	
}
void ugwApplication::ProcessSession(lteEpcTag tag){
	Ptr<Packet> packetSend = Create<Packet>();
	lteEpcTag tagSend;
	tagSend.m_Handover = tag.m_Handover;

	if(tag.getM_SessionModifyBearerRequest() == 1){
		std::cout<<"receive controller modifybearerrequest "<<(uint32_t)tag.getM_Handover()<<std::endl;
		tagSend.setM_Session();
		tagSend.setM_SessionModifyBearerResponse();
		packetSend->AddPacketTag(tagSend);
		m_sendToControllerSocket->SendTo(packetSend,0,InetSocketAddress(m_controllerSocketAddress,m_controllerPort));
	}
} 
void ugwApplication::ProcessPacket(Ptr<Packet> packet){
	lteEpcTag tag;
	packet->RemovePacketTag(tag);
	ProcessSession(tag);
/*	Ptr<Packet> packet;
	m_mutex.Lock();
	if(m_vec.size() == 0) std::cout<<"warning\n";
	packet = m_vec[m_vec.size() - 1];
	m_vec.pop_back();
	m_mutex.Unlock();
	lteEpcTag tag;
	packet->RemovePacketTag(tag);
	if(tag.getM_Session() == 1){
		ProcessSession(tag);	
	}*/
}
void ugwApplication::ProcessThread(void){
//	while(1){
//		m_signal.wait();
//		if(m_vec.size() > 0 ) ProcessPacket();	
//	}
//	m_mutex.Lock();
//	if(m_vec.size() > 0){
//		m_mutex.Unlock();
//		ProcessPacket();
//	}
//	else{
//		m_mutex.Unlock();
//	}
}
void ugwApplication::RecvFromEnbSocket(Ptr<Socket> socket){
	Ptr<Packet> packet = socket->Recv();
//	ProcessPacket(packet);
	Simulator::Schedule(Simulator::Now(),&ugwApplication::ProcessPacket,this,packet);
/*	m_mutex.Lock();
	m_vec.push_back(packet);
	m_mutex.Unlock();
	Simulator::Schedule(Simulator::Now(),&ugwApplication::ProcessPacket,this);*/
}

}
