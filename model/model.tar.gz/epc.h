/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef EPC_H
#define EPC_H

namespace ns3 {

/* ... */

}

#endif /* EPC_H */

