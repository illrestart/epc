
#include "controller-application.h"
#include "ns3/log.h"
#include "ns3/simulator.h"

NS_LOG_COMPONENT_DEFINE("controllerApplication");

namespace ns3{

TypeId controllerApplication::GetTypeId(void){
	static TypeId tid = TypeId("ns3::controllerApplication")
		.SetParent<Object>();
	return tid;
}

void controllerApplication::DoDispose(void){
	NS_LOG_FUNCTION(this);
}

controllerApplication::controllerApplication(Ptr<Node> controllerNode,Ipv4Address mmeSocketAddress,int mmeport,Ipv4Address ugwSocketAddress,int ugwport)
	:m_controllerNode(controllerNode),
	m_mmeSocketAddress(mmeSocketAddress),
        m_ugwSocketAddress(ugwSocketAddress),
	m_mmePort(mmeport),
	m_ugwPort(ugwport)
{
	m_port = 8086;

	InitSocket();
}
controllerApplication::~controllerApplication(void){
	NS_LOG_FUNCTION(this);
}
void controllerApplication::InitSocket(){
	m_socket = Socket::CreateSocket(m_controllerNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_socket->Bind(InetSocketAddress(Ipv4Address::GetAny(),m_port));

	m_sendToMmeSocket = Socket::CreateSocket(m_controllerNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_sendToMmeSocket->Bind(InetSocketAddress(Ipv4Address::GetAny(),8084));

	m_sendToUgwSocket = Socket::CreateSocket(m_controllerNode,TypeId::LookupByName("ns3::UdpSocketFactory"));
	m_sendToUgwSocket->Bind(InetSocketAddress(Ipv4Address::GetAny(),8085));

}
void controllerApplication::StartApplication(){
	NS_LOG_FUNCTION(this);	
	m_socket->SetRecvCallback(MakeCallback(&controllerApplication::RecvFromMmeSocket,this));
}
void controllerApplication::StopApplication(){
	NS_LOG_FUNCTION(this);	
}
void controllerApplication::ProcessSession(lteEpcTag tag){
	Ptr<Packet> packetSend = Create<Packet>();
	lteEpcTag tagSend;
	tagSend.m_Handover = tag.m_Handover;

	if(tag.getM_SessionUplinkData() == 1){
		std::cout<<"receive uplinkdata "<<(uint32_t)tag.getM_Handover()<<std::endl;
	}
	else if(tag.getM_SessionModifyBearerRequest() == 1){
		std::cout<<"rceive mme  modifybearerrequest "<<(uint32_t)tag.getM_Handover()<<std::endl;
		tagSend.setM_Session();
		tagSend.setM_SessionModifyBearerRequest();
		packetSend->AddPacketTag(tagSend);
		m_sendToUgwSocket->SendTo(packetSend,0,InetSocketAddress(m_ugwSocketAddress,m_ugwPort));
	}
	else if(tag.getM_SessionModifyBearerResponse() == 1){
		std::cout<<"rceive ugw modifycearerreqsponse "<<(uint32_t)tag.getM_Handover()<<std::endl;
		tagSend.setM_Session();
		tagSend.setM_SessionModifyBearerResponse();
		packetSend->AddPacketTag(tagSend);
		m_sendToMmeSocket->SendTo(packetSend,0,InetSocketAddress(m_mmeSocketAddress,m_mmePort));
	}
} 
void controllerApplication::ProcessPacket(Ptr<Packet> packet){
	lteEpcTag tag;
	packet->RemovePacketTag(tag);
	ProcessSession(tag);
/*	Ptr<Packet> packet;
	m_mutex.Lock();
	if(m_vec.size() == 0) std::cout<<"warning\n";
	packet = m_vec[m_vec.size() - 1];
	m_vec.pop_back();
	m_mutex.Unlock();
	lteEpcTag tag;
	packet->RemovePacketTag(tag);
	if(tag.getM_Session() == 1){
		ProcessSession(tag);	
	}*/
}
void controllerApplication::ProcessThread(void){
//	while(1){
//		m_signal.wait();
//		if(m_vec.size() > 0 ) ProcessPacket();	
//	}
//	m_mutex.Lock();
//	if(m_vec.size() > 0){
//		m_mutex.Unlock();
//		ProcessPacket();
//	}
//	else{
//		m_mutex.Unlock();
//	}
}
void controllerApplication::RecvFromMmeSocket(Ptr<Socket> socket){
	Ptr<Packet> packet = socket->Recv();
//	ProcessPacket(packet);
	Simulator::Schedule(Simulator::Now(),&controllerApplication::ProcessPacket,this,packet);
/*	m_mutex.Lock();
	m_vec.push_back(packet);
	m_mutex.Unlock();
	Simulator::Schedule(Simulator::Now(),&controllerApplication::ProcessPacket,this);*/
}
	

}
